package com.aistudio.mobile.ui

import android.content.ActivityNotFoundException
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.aistudio.mobile.R

class MainActivity : AppCompatActivity() {
    private val home = "https://ai.google.dev/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        openHomeAndFinish()
    }

    private fun openHomeAndFinish() {
        try {
            val intent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            intent.launchUrl(this, Uri.parse(home))
            // Close our activity so back returns to launcher, not blank screen
            finish()
        } catch (e: ActivityNotFoundException) {
            // Fallback WebView (Google sign-in may be limited in WebView)
            val wv = WebView(this)
            setContentView(wv)
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.settings.useWideViewPort = true
            wv.settings.loadWithOverviewMode = true
            wv.webViewClient = object: WebViewClient() {}
            wv.loadUrl(home)
        }
    }
}
